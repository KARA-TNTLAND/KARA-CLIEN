package dev.kara.client;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Map;
import java.util.HashMap;

/** KARA CLIENT's custom, original module menu. */
public final class KaraMenuScreen extends Screen {
    private static final int GOLD = 0xFFE7B85A;
    private static final int TEXT = 0xFFF2F3F7;
    private static final int MUTED = 0xFF9A9EAA;
    private static final int PANEL = 0xF0121318;
    private static final int PANEL_LIGHT = 0xFF202127;
    private static final int PANEL_DARK = 0xFF15161C;
    private static final int LINE = 0xFF30313A;
    private static final int GREEN = 0xFF72D6A0;
    private static final int RED = 0xFFFF5868;

    private static final int[] THEMES = {
            0xFF7B36B5, 0xFFE5394F, 0xFF8E1728, 0xFF25804D, 0xFFC49A24,
            0xFFFFD400, 0xFFD44B26, 0xFF8150B8, 0xFF245FC2, 0xFF1A4F7A, 0xFF287C9C
    };
    private static final String[] THEME_NAMES = {
            "Purple", "Red", "Dark Red", "Green", "Gold", "Yellow",
            "Red + Gold", "Purple + Gold", "Blue", "Blue + Red", "Blue + Gold"
    };

    private static final int MENU_W = 560;
    private static final int MENU_H = 340;
    private static final int MODULE_TOP = 116;
    private static final int MODULE_BOTTOM = 292;
    private static final int MODULE_ROW = 22;
    private static final int VISIBLE_ROWS = 8;

    private static int themeIndex = 1;
    private static boolean darkBackground = true;
    private ModuleCategory selectedCategory = ModuleCategory.COMBAT;
    private ClientModule selectedModule;
    private final List<ButtonWidget> categoryButtons = new ArrayList<>();
    private final List<ButtonWidget> moduleButtons = new ArrayList<>();
    private final Map<ButtonWidget, Integer> baseButtonY = new IdentityHashMap<>();
    private ButtonWidget themeButton;
    private ButtonWidget backgroundButton;
    private ButtonWidget hudSettingButton;
    private ButtonWidget modeSettingButton;
    private TextFieldWidget searchField;
    private String searchQuery = "";
    private final Map<ClientModule, Boolean> showInHud = new HashMap<>();
    private final Map<ClientModule, Integer> moduleModes = new HashMap<>();
    private static final String[] MODE_NAMES = {"Normal", "Smart", "Strict"};
    private int scroll = 0;
    private long transitionStart = System.currentTimeMillis();

    public KaraMenuScreen() {
        super(Text.literal("KARA CLIENT"));
    }

    @Override
    protected void init() {
        clearChildren();
        categoryButtons.clear();
        moduleButtons.clear();
        baseButtonY.clear();

        int x = panelX();
        int y = panelY();

        int categoryY = y + 82;
        for (ModuleCategory category : ModuleCategory.values()) {
            ButtonWidget button = ButtonWidget.builder(categoryLabel(category), b -> {
                selectedCategory = category;
                selectedModule = null;
                scroll = 0;
                searchQuery = "";
                init();
            }).dimensions(x + 12, categoryY, 104, 22).build();
            categoryButtons.add(button);
            addDrawableChild(button);
            categoryY += 28;
        }

        themeButton = ButtonWidget.builder(Text.literal("Theme: " + THEME_NAMES[themeIndex]), b -> {
            themeIndex = (themeIndex + 1) % THEMES.length;
            b.setMessage(Text.literal("Theme: " + THEME_NAMES[themeIndex]));
        }).dimensions(x + 320, y + 31, 112, 20).build();
        addDrawableChild(themeButton);

        backgroundButton = ButtonWidget.builder(backgroundLabel(), b -> {
            darkBackground = !darkBackground;
            b.setMessage(backgroundLabel());
        }).dimensions(x + 438, y + 31, 110, 20).build();
        addDrawableChild(backgroundButton);

        searchField = new TextFieldWidget(textRenderer, x + 130, y + 91, 204, 18, Text.literal("Search modules"));
        searchField.setMaxLength(48);
        searchField.setPlaceholder(Text.literal("Search modules..."));
        searchField.setText(searchQuery);
        searchField.setChangedListener(value -> {
            searchQuery = value;
            scroll = 0;
            updateModuleButtonVisibility();
        });
        addDrawableChild(searchField);

        List<ClientModule> visibleModules = selectedModules();
        int rowY = y + MODULE_TOP;
        for (ClientModule module : visibleModules) {
            ButtonWidget button = ButtonWidget.builder(moduleLabel(module), b -> {
                module.toggle();
                selectedModule = module;
                b.setMessage(moduleLabel(module));
                updateSettingButtons();
            }).dimensions(x + 126, rowY, 208, 20).build();
            moduleButtons.add(button);
            addDrawableChild(button);
            rowY += MODULE_ROW;
        }

        hudSettingButton = ButtonWidget.builder(hudSettingLabel(), b -> {
            if (selectedModule != null) {
                showInHud.put(selectedModule, !showInHud.getOrDefault(selectedModule, false));
                b.setMessage(hudSettingLabel());
            }
        }).dimensions(x + 363, y + 204, 175, 18).build();
        addDrawableChild(hudSettingButton);

        modeSettingButton = ButtonWidget.builder(modeSettingLabel(), b -> {
            if (selectedModule != null) {
                int next = (moduleModes.getOrDefault(selectedModule, 0) + 1) % MODE_NAMES.length;
                moduleModes.put(selectedModule, next);
                b.setMessage(modeSettingLabel());
            }
        }).dimensions(x + 363, y + 225, 175, 18).build();
        addDrawableChild(modeSettingButton);

        addDrawableChild(ButtonWidget.builder(Text.literal("Close  [P]"), b -> close())
                .dimensions(x + 426, y + 309, 122, 20).build());

        refreshCategoryLabels();
        updateModuleButtonVisibility();
        updateSettingButtons();
        captureButtonPositions();
    }

    private Text categoryLabel(ModuleCategory category) {
        return Text.literal((category == selectedCategory ? "§6◆ §f" : "§7◇ ") + category.title);
    }

    private Text backgroundLabel() {
        return Text.literal("Backdrop: " + (darkBackground ? "Dark" : "Soft"));
    }

    private void refreshCategoryLabels() {
        for (int i = 0; i < categoryButtons.size(); i++) {
            ModuleCategory category = ModuleCategory.values()[i];
            categoryButtons.get(i).setMessage(categoryLabel(category));
        }
    }

    private List<ClientModule> selectedModules() {
        List<ClientModule> result = new ArrayList<>();
        for (ClientModule module : ModuleRegistry.all()) {
            if (module.category() == selectedCategory) result.add(module);
        }
        return result;
    }

    private List<ClientModule> filteredModules() {
        String needle = searchQuery.trim().toLowerCase(java.util.Locale.ROOT);
        List<ClientModule> result = new ArrayList<>();
        for (ClientModule module : selectedModules()) {
            if (needle.isEmpty() || module.name().toLowerCase(java.util.Locale.ROOT).contains(needle)
                    || module.description().toLowerCase(java.util.Locale.ROOT).contains(needle)) {
                result.add(module);
            }
        }
        return result;
    }

    private Text hudSettingLabel() {
        return Text.literal("Show in HUD: " + (selectedModule != null && showInHud.getOrDefault(selectedModule, false) ? "ON" : "OFF"));
    }

    private Text modeSettingLabel() {
        int mode = selectedModule == null ? 0 : moduleModes.getOrDefault(selectedModule, 0);
        return Text.literal("Mode: " + MODE_NAMES[mode]);
    }

    private void updateSettingButtons() {
        if (hudSettingButton == null || modeSettingButton == null) return;
        boolean selected = selectedModule != null;
        hudSettingButton.visible = selected;
        hudSettingButton.active = selected;
        hudSettingButton.setMessage(hudSettingLabel());
        modeSettingButton.visible = selected;
        modeSettingButton.active = selected;
        modeSettingButton.setMessage(modeSettingLabel());
    }

    private Text moduleLabel(ClientModule module) {
        String state = module.enabled() ? "§a● §f" : "§8○ §f";
        return Text.literal(state + module.name());
    }

    private int panelX() { return Math.max(6, (width - MENU_W) / 2); }
    private int panelY() { return Math.max(6, (height - MENU_H) / 2); }

    private void captureButtonPositions() {
        for (net.minecraft.client.gui.Element child : children()) {
            if (child instanceof ButtonWidget button) baseButtonY.put(button, button.getY());
        }
    }

    private int openingOffset() {
        float t = Math.min(1.0f, (System.currentTimeMillis() - transitionStart) / 520.0f);
        // Ease-out cubic: starts quickly, then settles gently.
        float eased = 1.0f - (float) Math.pow(1.0f - t, 3.0);
        return Math.round((1.0f - eased) * 13.0f);
    }

    private void updateAnimatedButtonPositions() {
        int offset = openingOffset();
        for (Map.Entry<ButtonWidget, Integer> entry : baseButtonY.entrySet()) {
            entry.getKey().setY(entry.getValue() + offset);
        }
    }

    private void drawButtonHighlights(DrawContext context, int mouseX, int mouseY, int accent) {
        float pulse = 0.5f + 0.5f * (float) Math.sin(System.currentTimeMillis() / 260.0);
        for (int i = 0; i < categoryButtons.size(); i++) {
            ButtonWidget button = categoryButtons.get(i);
            boolean selected = ModuleCategory.values()[i] == selectedCategory;
            boolean hovered = mouseX >= button.getX() && mouseX < button.getX() + button.getWidth()
                    && mouseY >= button.getY() && mouseY < button.getY() + button.getHeight();
            if (selected || hovered) {
                int color = selected ? accent : 0xFF56627D;
                int alpha = selected ? (int) (45 + pulse * 28) : 65;
                context.fill(button.getX() - 2, button.getY() - 1, button.getX() + button.getWidth() + 2,
                        button.getY() + button.getHeight() + 1, (alpha << 24) | (color & 0x00FFFFFF));
                context.fill(button.getX() - 2, button.getY() - 1, button.getX() + 1,
                        button.getY() + button.getHeight() + 1, accent);
            }
        }
        for (ButtonWidget button : moduleButtons) {
            if (!button.visible) continue;
            boolean hovered = mouseX >= button.getX() && mouseX < button.getX() + button.getWidth()
                    && mouseY >= button.getY() && mouseY < button.getY() + button.getHeight();
            if (hovered) {
                context.fill(button.getX() - 2, button.getY() - 1, button.getX() + button.getWidth() + 2,
                        button.getY() + button.getHeight() + 1, 0x503E9BFF);
                context.fill(button.getX() - 2, button.getY() - 1, button.getX(),
                        button.getY() + button.getHeight() + 1, accent);
            } else {
                // A restrained rail keeps enabled modules easy to spot.
                int index = moduleButtons.indexOf(button);
                if (index >= 0 && selectedModules().size() > index && selectedModules().get(index).enabled()) {
                    context.fill(button.getX() - 1, button.getY() + 4, button.getX(),
                            button.getY() + button.getHeight() - 4, GREEN);
                }
            }
        }
    }

    private void updateModuleButtonVisibility() {
        int top = panelY() + MODULE_TOP;
        int bottom = panelY() + MODULE_BOTTOM;
        List<ClientModule> all = selectedModules();
        List<ClientModule> filtered = filteredModules();
        int visibleIndex = 0;
        for (int i = 0; i < moduleButtons.size(); i++) {
            ButtonWidget button = moduleButtons.get(i);
            ClientModule module = all.get(i);
            boolean matches = filtered.contains(module);
            if (!matches) {
                button.visible = false;
                button.active = false;
                continue;
            }
            int nextY = top + visibleIndex * MODULE_ROW - scroll;
            visibleIndex++;
            button.setY(nextY);
            button.visible = nextY >= top && nextY + button.getHeight() <= bottom;
            button.active = button.visible;
            baseButtonY.put(button, nextY);
        }
        if (searchField != null) searchField.visible = true;
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        int x = panelX();
        int y = panelY();
        boolean overModuleList = mouseX >= x + 124 && mouseX <= x + 347
                && mouseY >= y + MODULE_TOP && mouseY <= y + MODULE_BOTTOM;
        if (!overModuleList) return super.mouseScrolled(mouseX, mouseY, horizontalAmount, verticalAmount);

        int count = filteredModules().size();
        int maxScroll = Math.max(0, (count - VISIBLE_ROWS) * MODULE_ROW);
        scroll = Math.max(0, Math.min(maxScroll, scroll - (int) (verticalAmount * MODULE_ROW)));
        updateModuleButtonVisibility();
        return true;
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        long elapsed = System.currentTimeMillis() - transitionStart;
        float t = Math.min(1.0f, elapsed / 850.0f);
        int alpha = (int) ((darkBackground ? 226 : 165) * t);
        context.fill(0, 0, width, height, (alpha << 24) | 0x00060A12);
        updateAnimatedButtonPositions();

        int x = panelX();
        int y = panelY();
        int accent = THEMES[themeIndex];
        int right = x + MENU_W;
        int bottom = y + MENU_H;

        // Layered frame and accent rails
        context.fill(x + 4, y + 5, right + 4, bottom + 5, 0x65000000);
        context.fill(x, y, right, bottom, PANEL);
        context.fill(x, y, right, y + 2, accent);
        context.fill(x, bottom - 2, right, bottom, accent);
        context.fill(x, y, x + 2, bottom, accent);
        context.fill(right - 2, y, right, bottom, 0xFF28344D);
        // Animated accent sweep along the top rail.
        float sweepT = (elapsed % 1500L) / 1500.0f;
        int sweepX = x + 8 + (int) ((MENU_W - 24) * sweepT);
        context.fill(Math.max(x + 3, sweepX - 14), y, Math.min(right - 3, sweepX + 14), y + 2, 0xFFFFE7A3);
        // Soft glow blocks pulse subtly behind the logo.
        int glowAlpha = (int) (18 + 16 * (0.5 + 0.5 * Math.sin(elapsed / 240.0)));
        context.fill(x + 8, y + 8, x + 166, y + 54, (glowAlpha << 24) | (accent & 0x00FFFFFF));

        // Header
        context.fill(x + 3, y + 4, right - 3, y + 65, 0xFF191E2B);
        context.fill(x + 12, y + 14, x + 15, y + 47, accent);
        context.drawTextWithShadow(textRenderer, "KARA CLIENT", x + 23, y + 12, GOLD);
        context.drawTextWithShadow(textRenderer, "ROYAL UI  /  FABRIC 1.21.10", x + 23, y + 29, MUTED);
        context.drawTextWithShadow(textRenderer, "● VISUAL CLIENT MENU", x + 23, y + 46, GREEN);
        context.drawTextWithShadow(textRenderer, "SETTINGS", x + 320, y + 17, accent);

        // Column surfaces
        context.fill(x + 10, y + 72, x + 119, y + 302, PANEL_DARK);
        context.fill(x + 123, y + 72, x + 349, y + 302, 0xB0181D2A);
        context.fill(x + 353, y + 72, x + 550, y + 302, PANEL_DARK);
        context.fill(x + 120, y + 72, x + 122, y + 302, LINE);
        context.fill(x + 350, y + 72, x + 352, y + 302, LINE);

        context.drawTextWithShadow(textRenderer, "CATEGORIES", x + 18, y + 73, accent);
        context.drawTextWithShadow(textRenderer, selectedCategory.title.toUpperCase(), x + 132, y + 73, accent);
        context.drawTextWithShadow(textRenderer, "SEARCH", x + 130, y + 82, MUTED);
        context.drawTextWithShadow(textRenderer, "MODULE DETAILS", x + 363, y + 73, accent);

        // Hover and selection glows are drawn below the labels but above the panel surfaces.
        drawButtonHighlights(context, mouseX, mouseY, accent);

        // Scrollbar track and thumb
        List<ClientModule> modules = filteredModules();
        int visibleRows = VISIBLE_ROWS;
        int trackTop = y + MODULE_TOP;
        int trackBottom = y + MODULE_BOTTOM;
        context.fill(x + 340, trackTop, x + 343, trackBottom, 0xFF30384A);
        if (modules.size() > visibleRows) {
            int trackHeight = trackBottom - trackTop;
            int thumbHeight = Math.max(18, trackHeight * visibleRows / modules.size());
            int maxScroll = Math.max(1, (modules.size() - visibleRows) * MODULE_ROW);
            int thumbY = trackTop + (trackHeight - thumbHeight) * scroll / maxScroll;
            context.fill(x + 340, thumbY, x + 343, thumbY + thumbHeight, accent);
        }

        // Details panel
        String moduleName = selectedModule == null ? "Nothing selected" : selectedModule.name();
        String desc = selectedModule == null
                ? "Choose a module from the list to view its description and state."
                : selectedModule.description();
        context.drawTextWithShadow(textRenderer, moduleName, x + 363, y + 94, TEXT);
        context.fill(x + 363, y + 108, x + 538, y + 109, LINE);
        drawWrapped(context, desc, x + 363, y + 119, 174, MUTED, 11);

        boolean enabled = selectedModule != null && selectedModule.enabled();
        context.fill(x + 363, y + 250, x + 538, y + 274, 0xFF1B2230);
        context.fill(x + 363, y + 250, x + 366, y + 274, enabled ? GREEN : LINE);
        context.drawTextWithShadow(textRenderer, "MODULE STATUS", x + 372, y + 255, MUTED);
        context.drawTextWithShadow(textRenderer,
                selectedModule == null ? "—" : (enabled ? "ON" : "OFF"),
                x + 504, y + 255, enabled ? GREEN : (selectedModule == null ? MUTED : RED));
        context.drawTextWithShadow(textRenderer, selectedModule == null ? "Select a module to edit settings" : "Settings are stored per module", x + 363, y + 280, MUTED);

        // Footer
        context.fill(x + 10, y + 304, right - 10, y + 305, LINE);
        context.drawTextWithShadow(textRenderer, "KARA  •  ROYAL PvP", x + 13, y + 316, MUTED);
        context.drawTextWithShadow(textRenderer, "Search + scroll to browse", x + 185, y + 316, MUTED);

        super.render(context, mouseX, mouseY, delta);
    }

    private void drawWrapped(DrawContext context, String text, int x, int y, int maxWidth, int color, int lineHeight) {
        String[] words = text.split(" ");
        String line = "";
        int lineY = y;
        for (String word : words) {
            String test = line.isEmpty() ? word : line + " " + word;
            if (textRenderer.getWidth(test) > maxWidth && !line.isEmpty()) {
                context.drawTextWithShadow(textRenderer, line, x, lineY, color);
                line = word;
                lineY += lineHeight;
            } else {
                line = test;
            }
        }
        if (!line.isEmpty()) context.drawTextWithShadow(textRenderer, line, x, lineY, color);
    }

    @Override
    public void close() {
        MinecraftClient.getInstance().setScreen(null);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}
