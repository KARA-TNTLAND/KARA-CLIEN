package dev.kara.client;

public enum ModuleCategory {
    COMBAT("Combat"),
    PLAYER("Player"),
    MOVEMENT("Movement"),
    RENDER("Render"),
    WORLD("World"),
    MISC("Misc");

    public final String title;
    ModuleCategory(String title) { this.title = title; }
}
