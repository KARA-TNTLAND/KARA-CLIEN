package dev.kara.client;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public final class ModuleRegistry {
    private static final List<ClientModule> MODULES = new ArrayList<>();

    static {
        // These are UI toggles/placeholders until each module is implemented.
        add("Aura", "Needs clarification; no attack automation implemented.", ModuleCategory.COMBAT);
        add("Auto Crystal", "Crystal PvP helper placeholder; implementation not yet added.", ModuleCategory.COMBAT);
        add("Auto Totem", "Totem/equipment helper placeholder; implementation not yet added.", ModuleCategory.COMBAT);
        add("Auto Looting", "Automatically moves loot from opened chests/shulkers; implementation pending.", ModuleCategory.PLAYER);
        add("Auto Bow/Crossbow Aim", "Automatic bow and crossbow aiming; not implemented yet.", ModuleCategory.COMBAT);
        add("RG+Trap", "Reference: CatLean Auto Netherite Scrap; exact behavior needs further specification.", ModuleCategory.COMBAT);
        add("Auto Event", "Needs clarification.", ModuleCategory.MISC);
        add("Elytra", "Elytra utility; behavior to be specified.", ModuleCategory.MOVEMENT);
        add("Auto Pearl", "Pearl response helper; trigger and timing need specification.", ModuleCategory.COMBAT);
        add("Target Player", "Target/player helper; behavior to be specified.", ModuleCategory.COMBAT);
        add("Player ESP", "Visual player highlighting; implementation pending.", ModuleCategory.RENDER);
        add("Storage ESP", "Visual storage highlighting; implementation pending.", ModuleCategory.RENDER);
        add("Hit FX", "Visual hit effects; implementation pending.", ModuleCategory.RENDER);
        add("World Renderer", "World visual settings; implementation pending.", ModuleCategory.RENDER);
        add("Fly", "Movement module placeholder; not implemented.", ModuleCategory.MOVEMENT);
        add("Speed", "Movement module placeholder; not implemented.", ModuleCategory.MOVEMENT);
        add("Auto Bridge", "Builds a bridge beneath the player; implementation not yet added.", ModuleCategory.MOVEMENT);
        add("Auto Fish", "Fishing helper; behavior to be specified.", ModuleCategory.MISC);
        add("Free Cam", "Camera utility; implementation pending.", ModuleCategory.RENDER);
        add("Auto Mine", "Ore mining helper for common ores; implementation not yet added.", ModuleCategory.PLAYER);
        add("Anti Knockback", "Gameplay-altering behavior not implemented.", ModuleCategory.COMBAT);
        add("Auto EZ", "Chat phrase helper; manual/limited use only, implementation pending.", ModuleCategory.MISC);
        add("Nickname Mask", "Local-only nickname display replacement; server identity is unchanged.", ModuleCategory.MISC);
        add("Full Bright", "Brightness option; implementation pending.", ModuleCategory.RENDER);
        add("Tracers", "Visual lines; implementation pending.", ModuleCategory.RENDER);
        add("Xray", "Ore visibility option; implementation pending.", ModuleCategory.RENDER);
        add("Auto Armor", "Equipment helper; behavior to be specified.", ModuleCategory.PLAYER);
        add("Kill Server", "Disabled: bot spam or server disruption will not be implemented.", ModuleCategory.MISC);
        add("No Push", "Movement collision behavior not implemented.", ModuleCategory.MOVEMENT);
        add("Phase", "Movement/collision behavior not implemented.", ModuleCategory.MOVEMENT);
        add("Auto Buff", "Potion/effect helper; behavior to be specified.", ModuleCategory.PLAYER);
        add("Surround", "Needs clarification.", ModuleCategory.COMBAT);
        add("Auto Sprint", "Sprint helper; implementation pending.", ModuleCategory.MOVEMENT);
        add("Water Speed", "Movement helper; implementation pending.", ModuleCategory.MOVEMENT);
        add("Auto Tool", "Tool selection helper; behavior to be specified.", ModuleCategory.PLAYER);
        add("Auto Respawn", "Respawn helper; implementation pending.", ModuleCategory.PLAYER);
        add("Auto TPA Accept", "Needs clarification; server interaction not implemented.", ModuleCategory.MISC);
        add("No Delay", "Needs clarification.", ModuleCategory.MISC);
        add("Anti Resource Pack", "Server resource-pack prompt helper; behavior to be specified.", ModuleCategory.MISC);
        add("Elytra Fly", "Movement helper not implemented.", ModuleCategory.MOVEMENT);
        add("Sit", "Needs clarification.", ModuleCategory.MISC);
    }

    private static void add(String name, String desc, ModuleCategory cat) {
        MODULES.add(new ClientModule(name, desc, cat));
    }

    public static List<ClientModule> all() { return Collections.unmodifiableList(MODULES); }
}
